#!/bin/bash


var=$(ls | grep "\.csv")
echo "The files with .csv are:" $var




