#!/bin/bash

colours=(red blue green black white)

echo "My favourite colours are:" ${colours[*]}


