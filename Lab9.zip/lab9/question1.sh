#!/bin/bash


echo -e "This is line number 1.\n This is line number 2. \n\t This is line 3 indented with a tab character."

echo -e "Tips for programming:\n\t 1. Master the fundamentals\n\t 2. Learn by doing\n\t 3. Understand the 'why'\n\t 4. Practice regularly\n\t 5. Debug effectively\n\t 6. Read and analyse code\n\t 7. Break down problems\n\t 8. Utilze resources\n\t 9. Don't fear errors\n\t 10. Start small and iterate."

