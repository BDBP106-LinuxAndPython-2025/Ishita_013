#!/bin/bash

echo "My name is $1"


