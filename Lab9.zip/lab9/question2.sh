#!/bin/bash

name="Ishita Badola"
age=21
echo -e "My name is" $name", and I am" $age "years old."

